net=['MoviesHD1','MoviesHD2','MoviesHD3','MoviesHD4','BoxOffice_HD1','SeriesHD1','SeriesHD2','DramaHD1','gourmet','beJUNIOR','Jeem',
'Baraem','CartoonNetworkHD','CartoonNetworkAR','CartoonNetworkHindi','Baby_TV','CBeebies','DreamWorks','JimJam','FOXFamilyMovies',
'FOXActionMovies','Star_World_B','TCM','amc','Star_Movies_B','FOXHD','OutdoorChannel','V_HD','TravelChannel','Extreme','fatafeat'
,'FoodNetwork','HGTV','CBSreality','FXHD','DMAX','NatGeoWild_HD','NatGeoPeople_HD','NatGeo_HD','BBCEarth','AnimalPlanetHD'
,'AljazeeraDocumentary','TRTWorld','Euronews','CNNHD','Bloomberg_B','HLN','DTX','DLife','FineLiving']
chann=['SportsGlobalHD','News_ar','HD1','HD2','HD3','HD4','HD5','HD6','HD7','HD8','HD9','HD10','SportsHD11','SportsHD12','SportsHD13','SportsHD14','SportsHD15','SportsHD16','SportsHD17','4K','BS_NBA']
xm=['OSN_Movies','OSN_Cinema','OSN_Enigma','OSN_Movies_Disney','OSN_Movies_First_+2','OSN_Movies_First','OSN_Action','Star_Movies_HD','Paramount','OSN_Kids','OSN_Ya_Hala_Al_Oula','OSN_Ya_Hala','OSN_Yahala_Cinema','OSN_Series_First','OSN_Binge','OSN_Comedy','OSN_Mezze','OSN_Living','OSN_Kid_Zone_TV','Comedy_Central','Syfy','Star_World',
'Crime_And_Investigation_Network','Nat_Geo_HD','H2_HD','History_HD','Nat_Geo_People_HD','Discovery_Science_HD','Nat_Geo_Wild_HD','Al_Safwa',
'Discovery_ID','Cinema_2','Al_Yawm','Series_+2','Cinema_1','Series_Channel','E!_Entertainment_HD','B4U_Aflam','Discovery_HD','OSN_News','TLC_HD'
,'Baby_TV_Europe','Fashion_TV_HD','Disney_XD','MTV_Live_HD','Disney_HD','Disney_Junior','VH1','Music_Now','Bloomberg','NickToons_HD',
'Nick_Jr','Fann','Viva_TV','Nickelodeon_HD']
elc_channels=['Dubai_One_Channel',"Dubai_TV__Channel","Alhayat_TV_Channel","Al_Nahar_Drama_Channel","Cima_Channel","CBC_Drama_Channel","Nile_Drama_Channel"
,"MBC_Egypt_Channel","Zee_aflam_Channel","Sada_El_Balad_Drama_Channel","MBC_MASR_2_Channel","CBC_Channel",
"Abu_Dhabi_TV_Channel","_Sama_Dubai__Channel","Al_Nahar_TV_Channel","LDC__Channel","Al_Jadeed_TV_Channel",
"Nile_Comedy _Channel","Emirates_Channel","Alrai_TV_Channel","Nile_Life__Channel","Sada_El_Balad_Channel",
"LBCI_Channel","DMC_DRAMA_Channel","ON_E_Channel","Aloula_Channel","ON_Drama_Channel","Dubai_Zaman_Channel",
"Sharjah_TV_Channel","CBC_sofra_Channel","DMC_Channel","iFILM_TV_Channel","Al_sharqya_Channel","National_Geographic_Abu_Dhabi_Channel",
"TeN_TV_Channel","Syria_Drama_Channel","Amman_Channel","SBC_Channel","Alsumaria_Channel","Roya_Channel","MTV_Channel",
"Nessma_Channel","Oman_Channel","Fujairah_Channel","Al_Aoula_Morocco_Channel","almanar_Channel","Syria_TV_Channel",
"Al_Saeedah_Channel","2M_TV_Channel","Sama_TV_Channel","Mix_Channel"]

