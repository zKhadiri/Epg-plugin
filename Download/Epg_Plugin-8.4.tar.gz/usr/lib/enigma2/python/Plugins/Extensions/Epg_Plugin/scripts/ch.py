net=['beincinema','MoviesHD1','MoviesHD2','MoviesHD3','MoviesHD4','BoxOffice_HD1','SeriesHD1','SeriesHD2','DramaHD1','gourmet','beJUNIOR','Jeem',
'Baraem','CartoonNetworkHD','CartoonNetworkAR','CartoonNetworkHindi','Baby_TV_B','CBeebies','DreamWorks','JimJam','FOXFamilyMovies',
'FOXActionMovies_b','Star_World_B','TCM','amc','Star_Movies_B','FOXHD','OutdoorChannel','V_HD','TravelChannel','Extreme','fatafeat'
,'FoodNetwork','HGTV','CBSreality','FXHD','DMAX','NatGeoWild_HD','NatGeoPeople_HD','NatGeo_HD','BBCEarth','AnimalPlanetHD'
,'AljazeeraDocumentary','TRTWorld','Euronews','CNNHD','Bloomberg_B','HLN','DTX','DLife','FineLiving']

chann=['SportsGlobalHD','News_ar','HD1','HD2','HD3','HD4','HD5','HD6','HD7','HD8','HD9','HD10','SportsHD11','SportsHD12','SportsHD13','SportsHD14','SportsHD15','SportsHD16','SportsHD17','4K','BS_NBA']

xm=['OSN_On_Demand_HD','OSN_Ya_Hala_Al_Oula','OSN_Ya_Hala']

elc_channels=['AlhayatDrama','Mehwar','Kuwait','JordanTV','Watania2','RotanaKids','LanaPlusTV','MBC3','Zeealwan','AlKaheraWalNasTV','DubaiOne',"DubaiTV","AlhayatTV","AlNaharDrama","Cima","CBCDrama","NileDrama"
,"Zeeaflam","SadaElBaladDrama","CBC",
"SamaDubai","AlNaharTV",
"NileComedy","AlraiTV","NileLife","SadaElBalad","DMCDRAMA","ONE","Aloula","ONDrama","DubaiZaman",
"SharjahTV","CBCsofra","DMC","iFILMTV","Alsharqya",
"TeNTV","SyriaDrama","Amman","SBC","Alsumaria","Roya","MTVLebnon",
"Nessma","Oman","Fujairah","almanar","SyriaTV",
"AlSaeedah","SamaTV","Mix",'RotanaCinema','RotanaClassic','RotanaDrama','RotanaKhalijiah','RotanaComedy','LBC','AlDafrah','Lana',
'ARTAflam1','ARTAflam2','ARTCinema','ARTHekayat','ARTHekayat2','AlJadeedTV','LBCI','MasperoZaman','NetworkArabic','Watania1',
'AbuDhabiTV','Emirates','AbuDhabiDrama','SadaElBalad+2','AlKaheraWalNasTV2']

ZA=['M-NetHD','1MagicHD','M-NetMoviesPremierHD','M-NetMoviesSmileHD','M-NetMoviesAction+HD','SundanceTVHD','TomCruise',
    'M-NetMoviesAction','M-NetMoviesAllStarsHD','StudioUniversalHD','M-NETBinge','M-NetCityHD',
    'VUZUHD','UniversalTVHD','TeleMundoEnglish','BBCFirstHD','BBCBritHD','DiscoveryChannelHD','ComedyCentral','ITVChoiceHD',
    'E!EntertainmentHD','FOXHD','FOXLife','GinxeSportsHD','SuperSlamHD','BET','MTV','LifetimeEntertainment','CBSReality',
    'DiscoveryTLCHD','DiscoveryFamilyHD','TNTAfricaHD','eMoviesHD','M-NetMoviesZoneHD','eMoviesExtraHD','EVA','KykNETHD',
    'KykNETandKieHD','KyKNetNou','VIAHD','AfricaMagicEpic','AfricaMagicUrban','AfricaMagicFamily','RealTime','SABCEncore',
    'MojaLove','MojaLoveHD','MzansiMagicHD','MzansiWethuHD','MzansiBioskop','ZeeWorldHD','StarLifeHD','ROK','CBSJusticeHD',
    'DiscoveryIDHD','TVMall','BBCLifestyle','FoodNetworkHD','TheHomeChannel','HomeandGardenTVHD','FashionOne','TravelChannel',
    'PeoplesWeather','NationalGeographicChannel','NatGeoWild','BBCEarthHD','CuriosityStream','TheHistoryChannelHD','IGNITION',
    'SpiceTV','SABC1HD','SABC2HD','SABC3HD','e.TVHD','eTVExtraHD','NaijaStand-UpComedy','NigerianFestivals','BLITZHD','SuperSportHD1'
    ,'SuperSportHD2','SuperSportHD3','SuperSportHD4','SuperSportHD5','SuperSportHD6','SuperSportHD7','SuperSportHD8','SuperSportHD9',
    'SuperSportHD10','SuperSport11HD','SuperSportHD12','SuperSportMaximoHD','TellyTrack','SowetoTV','BayTV','1KZN','TshwaneTV',
    'CapeTownTV','GauTV','LesothoTV','NTAI','ToonamiHD','CartoonNetworkHD','Boomerang','DisneyChannel','DisneyChannelXD','Nickelodeon',
    'Cbeebies','NickJr','NickTOONS','DisneyJunior','JimJam','eToonz','PBSKids','MindsetPop','Mindset','ChannelOHD','MzansiMusic',
    'MTVbase','TRACEURBANHD','TRACEAfrica','SoundCity','OneGospel','TraceGospel','Dumisa','FAITH','DayStar','TBN','AfricanEaster',
    'EmmanuelTV','BBCWorldNews','CNNInternationalHD','SkyNews','eNewsChannelAfrica','SABCNews','NewzroomAfrika','AlJazeera',
    'RussiaToday','ParliamentaryService','CGTNNews','CNBCAfrica','BloombergTelevision','BusinessDay','NDTV24x7','EuroNewsAfrica',
    'KykNetLekker','RAIInternational','BesteVanNederlands','RTPI','TV5MondeAfrique','DeutscheWelle','CCTV4','SETAsia','B4UMovies',
    'ZeeTV','StarPlus','SunTV','StarVijay','Colors','SETMax','Telemundo(P)','EVA(P)','SICInternacional(P)','M-NetPlus1HD']
ent=['BEINMOVIESPREMIERE','BEINMOVIESACTION','BEINMOVIESDRAMA','BEINMOVIESFAMILY','BeInBoxOffice','BeInSeriesHD1','BeInSeriesHD2'
     ,'beINDrama','FOXACTIONMOVIES','FOXFAMILYMOVIESHD']

osn=['OSN_On_Demand_HD','OSN_Ya_Hala_Al_Oula','OSN_Ya_Hala','OSN_Pop_Up_Adel_Imam','OSN_Action','OSN_Movies_First','OSN_Mov_First_+2h','OSN_Movies','OSN_Enigma',
             'OSN_Kids','OSN_Movies_Disney','OSN_Cinema','Paramount_HD','Star_Movies_HD','OSN_YH_Cinema','Alfa_Series_HD',
             'Alfa_Series_+2_HD','Alfa_Al_Yawm_HD','Alfa_Al_Safwa','Alfa_Fann','Alfa_Cinema_1','Alfa_Cinema_2','Alfa_Music_Now',
             'OSN_Series_First','OSN_Binge','OSN_Comedy','Star_World_HD','TLC_HD','E!_HD','OSN_Mezze','OSN_Living','MTV_Live_HD',
             'VH1','Disney_Channel_HD','Disney_XD_HD','Nickelodeon_HD','Nick_Jr_HD','OSN_Kidzone','Baby_TV','OSN_News','Bloomberg'
             ,'Discovery_Channel_HD','Discovery_Science_HD','CI','History_HD','H2_HD','Nat_Geo_HD','Nat_Geo_Wild_HD','Nat_Geo_People_HD',
             'Comedy_Central_HD','Discovery_IDX_HD','Disney_Junior_HD','NickToons_HD','Sky_News_HD','ABS-CBN_Sports+Action','Aksyon_TV','ANC','ARC','CineMo','Cinema_One_Global',
             'CNBC_Europe','GMA_Life_TV','GMA_News_TV','GMA_Pinoy_TV','Lifestyle_Network','Net_25','TeleRadyo','TFC','VIVA_TV','Myx','OSN_Mix']

mbc=['MBC1','MBCDrama','MBCEgypt','MBCEgypt2','MBC4','MBC2','MBCAction','MBCBollywood','MBC+Drama','MBCMovieMax','MBCIraq','MBCCinq','Wanasah']

others=['Spacetoon','noordubai','Arriadia.ma','2M.ma','Medi1tv.ma','Aloula.ma']

eli=['Dubai One HD','Abu Dhabi TV HD','Al Emarat TV HD','Abu Dhabi Drama HD','Baynounah TV HD','Dubai TV HD','Sama Dubai HD',
     'Noor Dubai','Dubai Zaman TV','Sharjah TV HD','Sharqiya from kalba HD','Ajman TV HD','Al Dafrah HD','Saudi 1 HD','SBC HD','Zikrayat TV HD',
     'MBC+ eLife HD','MBC+ Variety HD']